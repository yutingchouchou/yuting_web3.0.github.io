# 上傳說明

這包檔案是給 yuting_web3.0.github.io 用的「新增檔案包」。

## 最簡單做法

1. 解壓縮此 zip。
2. 把裡面的 `Facebook.html` 和整個 `facebook/` 資料夾上傳到 GitHub repo 的根目錄。
3. 等 GitHub Pages 自動部署。
4. 進入：
   `https://yutingchouchou.github.io/yuting_web3.0.github.io/Facebook.html`

## 不會覆蓋原網站

這包預設不包含 index.html、不包含 css、不包含原本 b1/b2/g1 等檔案，所以不會破壞你原本網站。

## 如果你想在原本導覽列加入口

在每個頁面的 `<nav><ul>` 裡加入：

```html
<li><a href="Facebook.html">臉書文集</a></li>
```

如果是在 facebook/ 資料夾內的頁面，路徑要用：

```html
<li><a href="../Facebook.html">臉書文集</a></li>
```
